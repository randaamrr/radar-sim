import json
import numpy as np

from src.surface import scene_samples
from src.meshes import occluder_scene

FORMAT_VERSION = 2   # v2 adds normals and the occluder mesh


def export_scene(cfg, path):
    """Write the shared scene file: surface samples, normals, radars, meshes."""
    room = scene_samples(cfg)
    radars = cfg["radars"]

    scene = occluder_scene(cfg)
    if scene is None:
        verts = np.zeros((0, 3))
        faces = np.zeros((0, 3), dtype=np.int64)
    else:
        verts = np.asarray(scene.vertices, dtype=float)
        faces = np.asarray(scene.faces, dtype=np.int64)

    furn = cfg["furniture"]
    meta = {
        "format_version": FORMAT_VERSION,
        "seed": cfg["seed"],
        "room_size_m": cfg["room"]["size_m"],
        "grid_step_m": cfg["room"]["grid_step_m"],
        "n_points": int(len(room["points"])),
    }
    np.savez_compressed(
        path,
        points=room["points"],
        normal=room["normal"],
        area=room["area"],
        reflectance=room["reflectance"],
        strength=room["strength"],
        material=room["material"],
        surface=room["surface"],
        radar_names=np.array([r["name"] for r in radars], dtype=str),
        radar_pos_m=np.array([r["pos_m"] for r in radars], dtype=float).reshape(-1, 3),
        radar_yaw_deg=np.array([r["yaw_deg"] for r in radars], dtype=float),
        radar_pitch_deg=np.array([r["pitch_deg"] for r in radars], dtype=float),
        furniture_names=np.array([f["name"] for f in furn], dtype=str),
        furniture_materials=np.array([f["material"] for f in furn], dtype=str),
        occluder_vertices=verts,
        occluder_faces=faces,
        meta=json.dumps(meta),
    )
    return meta


def load_exported(path):
    data = np.load(path, allow_pickle=False)
    out = {k: data[k] for k in data.files if k != "meta"}
    out["meta"] = json.loads(str(data["meta"]))
    return out