import numpy as np

# eps_r: relative permittivity (real part), used at mm-wave frequencies.
# Values follow ITU-R P.2040 (building materials table). Verify against the
# recommendation before citing them in the paper.
MATERIALS = {
    "concrete":     {"eps_r": 5.31, "source": "ITU-R P.2040"},
    "wood":         {"eps_r": 1.99, "source": "ITU-R P.2040"},
    "glass":        {"eps_r": 6.27, "source": "ITU-R P.2040"},
    "plasterboard": {"eps_r": 2.94, "source": "ITU-R P.2040"},
    "metal":        {"eps_r": None, "source": "perfect conductor assumption"},
}


def reflectance(name):
    """Power reflectance at normal incidence (Fresnel), lossless approximation."""
    eps = MATERIALS[name]["eps_r"]
    if eps is None:
        return 1.0
    n = np.sqrt(eps)
    gamma = (1.0 - n) / (1.0 + n)
    return float(gamma ** 2)


def apply_materials(room):
    """Add 'reflectance' and 'strength' (= area * reflectance) per point."""
    table = {m: reflectance(m) for m in np.unique(room["material"])}
    refl = np.array([table[m] for m in room["material"]])
    out = dict(room)
    out["reflectance"] = refl
    out["strength"] = room["area"] * refl
    return out