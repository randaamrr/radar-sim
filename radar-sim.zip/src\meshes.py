import numpy as np
import trimesh


def room_shell_mesh(cfg):
    """Room as an inward-facing box (walls, floor, ceiling)."""
    L, W, H = cfg["room"]["size_m"]
    box = trimesh.creation.box(extents=[L, W, H])
    box.apply_translation([L / 2, W / 2, H / 2])
    box.invert()
    return box


def furniture_meshes(cfg):
    """One box mesh per furniture item: list of (name, material, mesh)."""
    out = []
    for it in cfg["furniture"]:
        x, y = it["pos_m"]
        w, d, h = it["size_m"]
        m = trimesh.creation.box(extents=[w, d, h])
        m.apply_translation([x + w / 2, y + d / 2, h / 2])
        out.append((it["name"], it["material"], m))
    return out


def occluder_scene(cfg):
    """All furniture merged into one mesh (the room shell never blocks
    a line of sight between two points inside the room)."""
    meshes = [m for _, _, m in furniture_meshes(cfg)]
    if not meshes:
        return None
    return trimesh.util.concatenate(meshes)


def visible(scene, origin, targets, eps=1e-3):
    """True for each target point the radar at `origin` can see directly."""
    targets = np.asarray(targets, dtype=float)
    if scene is None:
        return np.ones(len(targets), dtype=bool)
    origin = np.asarray(origin, dtype=float)
    vec = targets - origin
    dist = np.linalg.norm(vec, axis=1)
    dirs = vec / dist[:, None]
    origins = np.tile(origin, (len(targets), 1))
    loc, idx_ray, _ = scene.ray.intersects_location(
        origins, dirs, multiple_hits=True)
    hit_d = np.linalg.norm(loc - origin, axis=1)
    blocked = np.zeros(len(targets), dtype=bool)
    blocked[idx_ray[hit_d < dist[idx_ray] - eps]] = True
    return ~blocked