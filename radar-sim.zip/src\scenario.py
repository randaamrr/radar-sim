import yaml
import numpy as np

KNOWN_MATERIALS = {"concrete", "wood", "glass", "metal", "plasterboard"}


class ScenarioError(ValueError):
    pass


def load_scenario(path):
    with open(path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    if not isinstance(cfg, dict):
        raise ScenarioError("ملف السيناريو فارغ أو غير صالح")

    for key in ("seed", "room", "surfaces", "furniture"):
        if key not in cfg:
            raise ScenarioError(f"الحقل ناقص: {key}")

    room = cfg["room"]
    surfaces = cfg["surfaces"]
    furniture = cfg["furniture"]

    if not isinstance(room, dict) or not isinstance(surfaces, dict) or not isinstance(furniture, list):
        raise ScenarioError("نوع البيانات في room أو surfaces أو furniture غير صحيح")

    size = room.get("size_m")
    step = room.get("grid_step_m")
    if not isinstance(size, list) or len(size) != 3 or any(s <= 0 for s in size):
        raise ScenarioError("size_m لازم 3 أرقام موجبة")
    if step is None or step <= 0:
        raise ScenarioError("grid_step_m لازم يكون موجب")

    for surf, mat in surfaces.items():
        if mat not in KNOWN_MATERIALS:
            raise ScenarioError(f"خامة مجهولة في {surf}: {mat}")

    for item in furniture:
        x, y = item["pos_m"]
        w, d, h = item["size_m"]
        if item["material"] not in KNOWN_MATERIALS:
            raise ScenarioError(f"خامة مجهولة في {item['name']}")
        if x < 0 or y < 0 or x + w > size[0] or y + d > size[1] or h > size[2]:
            raise ScenarioError(f"{item['name']} طالع بره الغرفة")

    cfg.setdefault("radars", [])
    names = set()
    for r in cfg["radars"]:
        for key in ("name", "pos_m", "yaw_deg", "pitch_deg"):
            if key not in r:
                raise ScenarioError(f"radar field missing: {key}")
        if r["name"] in names:
            raise ScenarioError(f"duplicate radar name: {r['name']}")
        names.add(r["name"])
        x, y, z = r["pos_m"]
        if not (0 <= x <= size[0] and 0 <= y <= size[1] and 0 <= z <= size[2]):
            raise ScenarioError(f"{r['name']} is outside the room")
        if not -180 <= r["yaw_deg"] <= 180:
            raise ScenarioError(f"{r['name']}: yaw_deg must be in [-180, 180]")
        if not -90 <= r["pitch_deg"] <= 90:
            raise ScenarioError(f"{r['name']}: pitch_deg must be in [-90, 90]")

    return cfg


def radar_direction(yaw_deg, pitch_deg):
    """Unit boresight vector. yaw 0 -> +x, yaw 90 -> +y, negative pitch -> down."""
    yaw = np.radians(yaw_deg)
    pitch = np.radians(pitch_deg)
    return np.array([
        np.cos(pitch) * np.cos(yaw),
        np.cos(pitch) * np.sin(yaw),
        np.sin(pitch),
    ])
